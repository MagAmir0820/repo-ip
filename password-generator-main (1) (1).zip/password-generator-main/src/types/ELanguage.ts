export enum ELanguage {
  ru = 'ru',
  en = 'en',
}
