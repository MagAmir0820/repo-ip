export interface ICheckboxes {
  id: string
  name: string
  isChecked: boolean
  payload: string
}
